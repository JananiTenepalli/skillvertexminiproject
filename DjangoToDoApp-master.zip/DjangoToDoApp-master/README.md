# DjangoToDoApp
Download Project or Clone Repository, extract files and move inside project folder, and type the following commands.
<br>
Run Command "pip install -r requirements.txt"
<br>
Run Command "python manage.py runserver"